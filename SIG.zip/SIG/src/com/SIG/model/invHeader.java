package com.SIG.model;

import java.util.ArrayList;

public class invHeader {

    private int num;
    private String date;
    private String customer;

    private ArrayList<invLine> items;

    public invHeader() {
    }

    public invHeader(int num, String date, String customer) {
        this.num = num;
        this.date = date;
        this.customer = customer;
    }

    public ArrayList<invLine> getItems() {
        if (items == null) {
            items = new ArrayList<>();
        }
        return items;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public int getNum() {
        return num;
    }

    public void setNom(int num) {
        this.num = num;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public double getTotal() {
        double total = 0.0;
        for (invLine line : getItems()) {
            total += line.getTotal();
        }
        return total;
    }

    public String getAsCSV() {
        return num + "," + date + "," + customer;
    }
}
