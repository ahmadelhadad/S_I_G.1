package com.SIG.model;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

public class InvTableModel extends AbstractTableModel {

    private ArrayList<invHeader> invHeader;
    private String Columns[] = {"No.", "Date", "Customer", "Total"};

    public InvTableModel(ArrayList<invHeader> invHeader) {
        this.invHeader = invHeader;
    }

    @Override
    public int getRowCount() {
        return invHeader.size();
    }

    @Override
    public int getColumnCount() {
        return Columns.length;
    }

    @Override
    public String getColumnName(int column) {
        return Columns[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        invHeader invoice = this.invHeader.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return invoice.getNum();
            case 1:
                return invoice.getDate();
            case 2:
                return invoice.getCustomer();
            case 3:
                return invoice.getTotal();
            default:
                return "";
        }
    }

   

}
